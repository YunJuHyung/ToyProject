//
//  myPageViewController.swift
//  GDWebDesgin1
//
//  Created by 윤주형 on 6/23/24.
//

import UIKit

class MyPageViewController: UIViewController {

    @IBOutlet weak var mailAcceptStackView: UIStackView!
    @IBOutlet weak var smsAcceptView: UIStackView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        mailAcceptStackView.layer.borderWidth = 1
        mailAcceptStackView.layer.borderColor = UIColor.systemGray3.cgColor
        mailAcceptStackView
            .layer.cornerRadius = 5
        
        smsAcceptView.layer.borderWidth = 1
        smsAcceptView.layer.borderColor = UIColor.systemGray3.cgColor
        smsAcceptView
            .layer.cornerRadius = 5
        
    }

}

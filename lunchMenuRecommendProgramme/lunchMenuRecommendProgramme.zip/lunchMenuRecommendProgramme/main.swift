//
//  main.swift
//  lunchMenuRecommendProgramme
//
//  Created by 윤주형 on 7/3/24.
//


//

import Foundation
var secondMenuCategories: [String] = []

func main() {
    
    var programRunning: Bool = true
    var startPoints: Bool = true
    
    var MenuCategories: [String] = []
    
    var count = 1
//    let arrayLength = MenuCategories.count - 1
    
    print("점심 메뉴 추천 프로그램을 실행합니다.")
    while startPoints {
        print("메뉴의 번호를 선택해주세요.")
        print("1. [점심 메뉴 추가] 2. [랜덤돌리기] 3. 종료는입니다.")
        
        
        let mainSelection = readLine()
        switch mainSelection {
        case "1":
            print("[점심 메뉴 추가]를 선택했습니다.")
            print("추가할 점심 메뉴를 입력해주세요.")
            
            while let MenuInput = readLine() {
                
                
                
                if MenuInput == "end" {
                    break
                }
                MenuCategories.append(MenuInput)
                let set = Set(MenuCategories)
                if count >= 2 && MenuCategories.count != set.count {
                    print("이미 있는 메뉴입니다.")
                    MenuCategories.remove(at: MenuCategories.count - 1)
                } else {
                    print("\(count)번째 메뉴: \(MenuInput)")
                    count += 1
                }
                    print("완료됐다면 end를 입력해주세요.")
                
//                    print("추가할 점심 메뉴를 입력해주세요.")
//                for element in MenuCategories {
//                    print("배열 엘리먼트 \(element)")
//                }
//                print("======================")
//                for setelement in set {
//                    print("set 엘리먼트 \(setelement)")
//                }
            }
            secondMenuCategories = MenuCategories
            count = 1
            
        case "2":
            
            /*반복문*/
            //로직 설명 n개의 값을 100에서 나누고 나눈 몫을 각 값에 부여 Roll
            //한번 롤 할때 선택된 값의 확률에서 x 몫/100 16%가됨
            //다른 값의 확률에 더하기 = 빠진 퍼센트를 / 총 값의 갯수 - 1
            
            if MenuCategories.isEmpty {
                print("점심 메뉴를 추가하고 돌려주세요!")
                break
            }
            print("[랜덤 돌리기]를 선택했습니다.")
            
            //100% / 전체메뉴갯수(n) == 100% / 메뉴가5개 = 각 메뉴당 초기확률 20%
            // 착각하지말자 eachMenuDefaultPercentage는 100퍼센트의 확률 / 배열의 갯수
           let eachMenuDefaultPercentage = 100 / MenuCategories.count
            //dictionary를 사용해서 [메뉴 : 확률] 저장
            var MenuDictionary: [String: Double] = [:]
            for index in MenuCategories{
                MenuDictionary[index] = Double(eachMenuDefaultPercentage)
            }
            //새로운 사실 dictionary는 순서대로 저장되지 않는다.

           // var checkend: Bool = true
            while programRunning {

//                while checkend {
                    //이제 롤 돌리면서 하나씩 뽑아냄
                    if let selectedMenu = MenuDictionary.randomElement()?.key {
                        // 뽑힌 메뉴는 기존 확률의 20%씩 낮추춤
                        let selectedMenuValueDecrease = Double(eachMenuDefaultPercentage) * 0.2
                        //selectedMenuValueDecrease origin확률을 20% 낮춘값
                        /** 진짜 놀라운 사실 딕셔너리의 key 값을 넣어줘서 value값이 튀어나오는 거같음**/
                        if let currentSelectedMenuValue = MenuDictionary[selectedMenu] {
                            MenuDictionary[selectedMenu] = currentSelectedMenuValue - selectedMenuValueDecrease
                        }
                        
                        // 뽑히지 않은 메뉴에 더해줄 값 MenuDictionary value = (selectedMenu * 0.2) / 배열의 총 갯수 - 1
                        let deSelectedMenuValue = selectedMenuValueDecrease / Double(MenuDictionary.count - 1)
                        // key값과 선택된 메뉴의 값이 일치하면 패스하고 다른 value값에 확률을 더해줌
                        for (key, value) in MenuDictionary {
                            if key != selectedMenu {
                                MenuDictionary[key] = value + deSelectedMenuValue
                                
                                
                                if MenuDictionary[key] == 0 {
                                    print("절대 도달할수 없지만 value값이 0에 도달")
                                }
                            }
                        }
                        print("현재 전체 확률은: \(MenuDictionary)")
                        print("뽑힌 메뉴는:\(selectedMenu), 확률은: \(MenuDictionary[selectedMenu]!)값 입니다.\n")
                        print("종료하고 싶으면 end를 입력해주세요")
                        let getEndPoint = readLine()
                        
                        if getEndPoint == "end" {
                            programRunning = false
                        }
                    }
            //    } // while checkend
            } // while programmingRunning
            
//               MARK: -- 기존 배열의 내용을 하나씩 없애는 case:2
//                if MenuCategories.isEmpty {
//                    print("**더이상 추천 메뉴가 없습니다. 초기 상태로 돌립니다.**\n")
//                    MenuCategories = secondMenuCategories
//                    count = 1
//                }
//                
//                if let Menu = MenuCategories.indices.randomElement(){
//                    
//                    let removedString = MenuCategories[Menu]
//                    MenuCategories.remove(at: Menu)
//                    
//                    print("======= 룰렛을 돌립니다 =======\n")
//                    do { sleep(1)}
//                    print("********************************")
//                    print("\(count)번째 추천 점심 메뉴는 \(removedString)입니다.")
//                    print("********************************\n")
//                    do { sleep(1)}
//                    
//                    var collectInput: Bool = true
//                    while collectInput {
//                        print("원치 않는 메뉴이면 roll을 만족하면 end를 입력해주세요")
//                        let userInput = readLine()
//                        if userInput == "roll" {
//                            count += 1
//                            collectInput = false
//                        }
//                        else if userInput == "end"{
//                            print("\(removedString) 먹으러 가자")
//                            programRunning = false
//                            collectInput = false
//                        }
//                        else {
//                            print("제대로 입력해주세요.")
//                        }
//                    }
//                }
            
            
        case "3":
            print("3번 입력으로 프로그램을 종료합니다.")
            startPoints = false
            
            
        default:
            print("잘못된 선택으로 프로그램을 종료합니다.")
            startPoints = false
        }
        
    }
}


main()

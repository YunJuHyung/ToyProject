//
//  UserInfo+CoreDataClass.swift
//  todo-List(CoreData)
//
//  Created by 윤주형 on 8/18/24.
//
//

import Foundation
import CoreData


public class TodoList: NSManagedObject {



    
}
